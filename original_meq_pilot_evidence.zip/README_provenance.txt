Original pilot evidence bundle

Source recovered from D:\Lakshmi Maheswari\MEQ\meq_pilot.py. Associated run output recovered from the same directory as results.json; script timestamp: 2026-10-28 06:57:30, results timestamp: 2026-10-28 06:57:37. The copied source and data are unmodified.

The source sets E_DEC=0.012, H_DEC=0.015, GAIN=0.7, and K=10. The results.json config records 2,000 training episodes, 10 seeds, 200-step horizon, 100 evaluation episodes, and shift rate 1.6.

The manuscript sentence that the decay and gain values were "adjusted once, after a short exploratory run" is NOT confirmed by these files. They show the final values and a later run output, but contain no earlier values, exploratory-run record, change log, or evidence that exactly one adjustment occurred. Treat the historical statement as unverified unless supported by author records or personal confirmation.
