# MEQ replication package

Manuscript: "The Machine Emotional Quotient (MEQ) as a Candidate Framework for Artificial Affective Regulation" (Discover Robotics submission).
Author: Dr. Jagadeesh Selvaraj, NextGen Technologies Private Limited, Chennai.
Requires Python 3 with NumPy. Run each script from a folder that contains an `outputs/` subfolder holding `meq_independent_reimplementation.py` (scripts load it from there and write outputs there).

## Contents

| Folder | What it holds | Verification (re-run on 2026-11-26) |
|---|---|---|
| `MEQ_Springer_Nature_Format_FINAL.docx` | Final manuscript | — |
| `original_pilot/` | `meq_pilot.py` and `results.json` (pilot behind manuscript Tables 6, 7, 13); provenance note; earlier article version | `python meq_pilot.py 2000` reproduces `results.json` exactly (0 differences, seed 2026, about 4.5–6.5 min) |
| `simulation_code/` | Extended-simulation scripts: reimplementation (world and learner), episode diagnosis, full-budget qualification, regression deep dive, 20-seed focused checkpoint check | Diagnosis, full-budget and regression outputs reproduce exactly; focused check reproduced exactly for training seed 31000 (other 19 seeds not re-run) |
| `simulation_outputs/` | CSV/JSON outputs of those scripts, plus the 300-episode, 10-seed factorial and intervention results | As above |
| `protocol_and_reports/` | Follow-up protocol and written reports | — |
| `repository_snapshot_extras/` | Figures, LaTeX source, bibliography and README from the public repository snapshot | — |
| `provenance_unknown/` | Four-start, 20-seed, 1,200-episode factorial and intervention outputs, and a file named `meq_pilot_REIMPLEMENTATION_mislabeled.py` | **Not reproducible.** No generating script found (see its README). The mislabeled file is the reimplementation, not the original pilot. The manuscript does not use these outputs. |

## Known limits
- Evaluation-seed schemes differ between the pilot (single seeded stream, random non-hazard starts) and the extended simulation (fixed starts (0,0) and (0,6), fixed event order).
- Original tuning history of the pilot's decay and gain values is not documented in these files.
- No RoboBATT analysis script is included.
