Four-start factorial artifact bundle

Copied from D:\NextGen Technologies\Publication\MEQ\Reimplementation.
The summary JSON records 20 seeds, 1,200 episodes, 100 evaluations per seed, and starts (0,0), (0,6), (6,0), (6,6). The factorial CSV has 320 rows; the intervention CSV has 240 rows.

The accompanying meq_independent_reimplementation.py does NOT match those recorded outputs: its current source specifies 10 seeds, 300 episodes, 40 evaluation episodes, and two starts. Treat it as a nearby source file, not verified provenance for these output files. The generating version/script for the 20-seed outputs was not found during the computer search.
